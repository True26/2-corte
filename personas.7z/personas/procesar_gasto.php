<?php

require "config/conexi.php";

$id = $_POST["id"];
$gasto = $_POST["gasto"];

$sql = "UPDATE clientes
SET

saldo= '".$gasto."'
WHERE

id=".$id.""; 

if($dbh->query($sql))

{
    echo "Datos actualizados correctamente";
}else{
    echo "Los datos no se han podido actualizar";
}

?>